#include "shell_util.h"
#include "linkedList.h"
#include "helpers.h"

// Library Includes
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>

int main(int argc, char *argv[])
{
	int i; //loop counter
	char *args[MAX_TOKENS + 1];
	int exec_result;
	int exit_status;
	volatile int childFlag = 0;
	pid_t pid;
	pid_t wait_result;
 	List_t *bg_list = malloc(sizeof(List_t));

        int secondsComparator(void *process1, void *process2)
	{
		ProcessEntry_t *p1 = process1, *p2 = process2;
		if(p1->seconds < p2->seconds)
			return -1;
		else if(p1->seconds > p2->seconds)
			return 1;
		return 0;
	}

	void sigchild_handler(int sig)
	{
		childFlag = 1; 
	}
	signal(SIGCHLD, sigchild_handler);

    //Initialize the linked list
    bg_list->head = NULL;
    bg_list->length = 0;
    bg_list->comparator = secondsComparator;  // Don't forget to initialize this to your comparator!!!

	void siguser_handler(int sig)
        {
		node_t *n = bg_list->head;
		while(n != NULL)
		{
			ProcessEntry_t *p = malloc(sizeof(ProcessEntry_t));
			p = n->value;
			printBGPEntry(p);
			n = n->next;
		}
        }
        signal(SIGUSR1, siguser_handler);

	// Setup segmentation fault handler
	if(signal(SIGSEGV, sigsegv_handler) == SIG_ERR)
	{
		perror("Failed to set signal handler");
		exit(-1);
	}

	while(1) {
		time_t t = time(NULL);
		// DO NOT MODIFY buffer
		// The buffer is dynamically allocated, we need to free it at the end of the loop
		char * const buffer = NULL;
		size_t buf_size = 0;

		// Print the shell prompt
		display_shell_prompt();
		
		// Read line from STDIN
		ssize_t nbytes = getline((char **)&buffer, &buf_size, stdin);

		// No more input from STDIN, free buffer and terminate
		if(nbytes == -1) {
			free(buffer);
			break;
		}

		// Remove newline character from buffer, if it's there
		if(buffer[nbytes - 1] == '\n')
			buffer[nbytes- 1] = '\0';

		// Handling empty strings
		if(strcmp(buffer, "") == 0) {
			free(buffer);
			continue;
		}
		
		// Parsing input string into a sequence of tokens
		size_t numTokens;
		*args = NULL;
		numTokens = tokenizer(buffer, args);

		if(strcmp(args[0],"exit") == 0) {
			// Terminating the shell
			node_t *n = bg_list->head;
			while(n != NULL)
			{
				ProcessEntry_t *p = malloc(sizeof(ProcessEntry_t));
				p = n->value;
				kill(p->pid, 1);
				printf(BG_TERM, p->pid, p->cmd);
				n = n->next;
			}
			free(buffer);
			return 0;
		}
		
		if(strcmp(args[0],"cd") == 0)
                {
                        char s[100];
                        if(args[1] == NULL)
                        {
                                chdir("/home");
                                printf("%s\n",getcwd(s,100));
                        }
                        else
                        {
                                int ret;
                                ret = chdir(args[1]);
                                if(ret != 0)
                                        fprintf(stderr, DIR_ERR);
                                else
                                        printf("%s\n",getcwd(s,100));
                        }
                        continue;
                }

		if(strcmp(args[0],"estatus") == 0)
		{
			printf("%d\n",WEXITSTATUS(exit_status));	

			continue;
		}
		
		int j = 0, pFlag = 0, inIndex = 0, outIndex = 0;
                char **in = malloc(sizeof(char*)*100), **out = malloc(sizeof(char*)*100);
                      
	        while(args[j] != NULL)
                {
                        if(strcmp(args[j],"|") == 0)
                        	pFlag = 1;
                        else if(pFlag == 1)
                        {
                                out[outIndex] = args[j];
                                outIndex++;
                        }
                        else
                        {
                                in[inIndex] = args[j];
                                inIndex++;
                        }
                                j++;
                }

		if(strcmp(args[numTokens-1],"&") == 0)
                {
                        ProcessEntry_t *p = malloc(sizeof(ProcessEntry_t));
                        p->cmd = realloc(p->cmd, 255);
                        for(i = 0; i < numTokens; i++)
                        {
                                strcat(p->cmd, args[i]);
                                if(i+1 != numTokens)
                                        strcat(p->cmd, " ");
                        }
                        p->pid = pid;
                        p->seconds = t;
                        insertInOrder(bg_list, (ProcessEntry_t*)p);
                        //args[numTokens-1] = NULL;
                        //                        //printf("%s\n", p->cmd);
                        //                                        }
                }

		int pipeFlag = 0, errorFlag = 0;
		for(i = 0; i < numTokens; i++)
		{
			if(strcmp(args[i], "|") == 0)
			{
				pipeFlag = 1;
				pid = fork();
				int fd[2];

				pipe(fd);
				pid = fork();

				if(pid == 0)
				{
					dup2(fd[1], 1);
					close(fd[0]);
					close(fd[1]);
					execvp(*in, in);
					exit(EXIT_SUCCESS);
				}
				else
				{
					pid = fork();
		
					if(pid == 0)
					{
						dup2(fd[0], 0);
						close(fd[1]);
						close(fd[0]);
						execvp(*out, out);
						exit(EXIT_SUCCESS);
					}
					else
					{
						int status;
						close(fd[0]);
						close(fd[1]);
						waitpid(pid, &status, 0);
					}
				}
			}
		}

		if(pipeFlag != 1)
		{
		pid = fork();   //In need of error handling......

		if (pid == 0){ //If zero, then it's the child process
			int fd, flag1 = 0, flag2 = 0, flag3 = 0, flag4 = 0;
			for(i = 0; i < numTokens; i++)
			{
				if(strcmp(args[i], "<") == 0)
				{
					flag1++;
					args[i] = NULL;
				
					if(args[i+1] == NULL || (fd = open(args[i+1], O_RDONLY, 0644)) < 0 || flag1 > 1)
					{
						fprintf(stderr, RD_ERR);
						errorFlag = 1;
						break;
					}
					dup2(fd, 0);
					close(fd);
				}
				else if(strcmp(args[i], ">") == 0)
				{
					flag2++;
					args[i] = NULL;

					if(args[i+1] == NULL || (fd = open(args[i+1], O_WRONLY | O_TRUNC | O_CREAT, 0644)) < 0 || flag2 > 1)
					{
						fprintf(stderr, RD_ERR);
						errorFlag = 1;
						break;
					}
					dup2(fd, 1);
					close(fd);
				}
				else if(strcmp(args[i], ">>") == 0)
				{
					flag3++;
					args[i] = NULL;
					if((fd = open(args[i+1], O_WRONLY | O_APPEND | O_CREAT, 0644)) < 0 || flag3 > 1)
					{
						fprintf(stderr, RD_ERR);
						errorFlag = 1;
						break;
					}
					dup2(fd, 1);
					close(fd);
				}
				else if(strcmp(args[i], "2>") == 0)
				{
					flag4++;
					args[i] = NULL;
					if((fd = open(args[i+1], O_WRONLY | O_TRUNC | O_CREAT, 0644)) < 0 || flag4 > 1)
					{
						fprintf(stderr, RD_ERR);
						errorFlag = 1;
						break;
					}
					dup2(fd, 2);
					close(fd);
				}
			}
			if(errorFlag == 0)
			{
				exec_result = execvp(args[0], &args[0]);
				if(exec_result == -1){ //Error checking
					printf(EXEC_ERR, args[0]);
					exit(EXIT_FAILURE);
				}
			}
		  exit(EXIT_SUCCESS);
		}
		else{ // Parent Process	
			if(childFlag == 1)
			{
				node_t *n = bg_list->head;
				int check;
				for(i = 0; i < bg_list->length; i++)
				{
					ProcessEntry_t *pe = n->value;
					if(waitpid(pe->pid, &check, WNOHANG) != 0)
					{
						wait_result = waitpid(pe->pid, &exit_status, 0);
						printf(BG_TERM, pe->pid, pe->cmd);
						removeByPid(bg_list, pe->pid);
						i--;
					}
					n = n->next;
				}
				childFlag = 0;
			}
			if(strcmp(args[numTokens-1], "&") != 0)
			{
				wait_result = waitpid(pid, &exit_status, 0);
				if(wait_result == -1){
					printf(WAIT_ERR);
					exit(EXIT_FAILURE);
				}
			}
		}
		}
		// Free the buffer allocated from getline
		free(buffer);
	}
	return 0;
}

